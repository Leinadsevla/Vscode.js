//"João, "João, o total da sua conta com taxa de serviço é R$63,58." R$63,58."
let cliente = "Joaquim";
let total = 60.80;
let taxaServico = 10;
let totalFinal = total + (total * taxaServico / 100);

console.log(`${cliente},o total da sua conta com taxa de serviço é R$ ${totalFinal} .`);